/*
  血壓紀錄小幫手 - Service Worker
  - 預先快取 App Shell（index/manifest/icons）
  - 同源資源採 Cache First；跨網域（CDN）採 Network First + 快取
*/

const CACHE_NAME = 'bp-pwa-v7';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './service-worker.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png',
  './medals/medal-1.png',
  './medals/medal-2.png',
  './medals/medal-3.png',
  './medals/medal-4.png',
  './medals/medal-5.png',
  './medals/medal-6.png',
  './medals/medal-7.png',
  './medals/medal-8.png',
  './medals/medal-9.png',
  './medals/medal-10.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_NAME)
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  const isSameOrigin = url.origin === self.location.origin;

  // 導覽請求：離線時回到 index.html
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put('./index.html', copy));
          return res;
        })
        .catch(() => caches.match('./index.html'))
    );
    return;
  }

  if (isSameOrigin) {
    // 同源：Cache First
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req).then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy));
          return res;
        });
      })
    );
  } else {
    // 跨網域（Tailwind/Chart.js/Lucide CDN）：Network First（成功就快取，失敗就回快取）
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req))
    );
  }
});
